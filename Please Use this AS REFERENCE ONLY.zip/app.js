var dateofbirthid;

function checker()
{
    if(document.getElementById("passwordid").value != document.getElementById("cpasswordid").value)
    {
        document.getElementById("passwordid").style.color = "red";
        alert("Password does NOT match!!!")
        return false;
    }
    else
    {
        dateofbirthid = prompt("Enter your dob");
        document.getElementById("output4").innerHTML = dateofbirthid;
        return true;
    }
}


function showinput()
{
    var temp1 = document.getElementById("usernameid").value;
    document.getElementById("output1").innerHTML = temp1;

    var temp2 = document.getElementById("passwordid").value;
    document.getElementById("output2").innerHTML = temp2;
    
    var temp3 = document.getElementById("cpasswordid").value;
    document.getElementById("output3").innerHTML = temp3;
}