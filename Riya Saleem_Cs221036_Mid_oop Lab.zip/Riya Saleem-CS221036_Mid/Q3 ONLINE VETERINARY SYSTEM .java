/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.question2umldiagram;

/**
 *
 * @author riyas
 */
// Animal class
class Animal {
    private int age;

    public Animal(int age) {
        this.age = age;
    }

    public int getAge() {
        return age;
    }

    public boolean isMammal() {
        return false;
    }
}

// Fish class
class Fish extends Animal {
    public Fish(int age) {
        super(age);
    }

    public void swim() {
        System.out.println("Fish is swimming.");
    }
}

// Duck class
class Duck extends Animal {
    public Duck(int age) {
        super(age);
    }

    public void swim() {
        System.out.println("Duck is swimming.");
    }

    @Override
    public boolean isMammal() {
        return false;
    }

    public void quack() {
        System.out.println("Duck is quacking.");
    }
}

// Zebra class
class Zebra extends Animal {
    public Zebra(int age) {
        super(age);
    }
}

// Main class
public class OnlineVeterinarySystem {
    public static void main(String[] args) {
        Duck duck = new Duck(2);
        Fish fish = new Fish(5);
        Zebra zebra = new Zebra(10);

        System.out.println("Age of Duck is " + duck.getAge() + " years.");
        System.out.println("Age of Fish is " + fish.getAge() + " years.");
        System.out.println("Age of Zebra is " + zebra.getAge() + " years.");
        

       
    }
}
